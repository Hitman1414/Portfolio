import React from "react";
import { motion } from "framer-motion";
import "./Skills.css";

function Skills() {
  const skills = [
    { name: "ReactJS", level: "Advanced" },
    { name: "Node.js", level: "Advanced" },
    { name: "Express.js", level: "Intermediate" },
    { name: "MySQL", level: "Intermediate" },
    { name: "Bootstrap", level: "Advanced" },
  ];

  return (
    <motion.section
      id="skills"
      className="skills-section"
      initial={{ opacity: 0, scale: 0.99 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.7 }}
    >
      <div className="container-fluid">
        <div className="row align-items-center gx-5">
          {/* LEFT: sticky image */}
          <motion.div
            className="col-lg-4 left-col"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9 }}
          >
            <div className="sticky-img-wrap">
              <img
                src="/skills-img.png"
                alt="Neon Skills"
                className="img-fluid neon-skill-img"
              />
            </div>
          </motion.div>

          {/* RIGHT: glowing skill cards */}
          <motion.div
            className="col-lg-8 right-col"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9 }}
          >
            <h1 className="skills-title neon-text">Skills</h1>

            <div className="skills-card-grid">
              {skills.map((skill, i) => (
                <motion.div
                  key={skill.name}
                  className="skill-card"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: i * 0.1 }}
                >
                  <h3 className="skill-card-title">{skill.name}</h3>
                  <p className="skill-card-level">{skill.level}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}

export default Skills;
